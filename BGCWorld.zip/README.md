# BGCWorld

Improved version for the current BBGC V4.2. Including

a. High temperature and correction

b. MCMC training

c. LAI module

d. Freezing module

e. GSI module
